export const users = new Map([
  ['guest', { password: 'guest', role: 'sinjo' }],
]);
